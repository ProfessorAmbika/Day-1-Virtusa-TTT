package siet.calculatorDependency;

import java.util.Scanner;

import siet.Calculator.Arith;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	try (//System.out.println( "Hello World!" );
    			Scanner s = new Scanner(System.in)) {
    				System.out.println("Enter the value1:");
    				int val1=s.nextInt();
    				System.out.println("Enter the value1:");
    				int val2=s.nextInt();
    				Arith a=new Arith();
    				int ad=a.add(val1, val2);
    				int su=a.sub(val1, val2);
    				int mu=a.multi(val1, val2);
    				float di=a.div(val1, val2);
    				int mo=a.mod(val1, val2);
    				System.out.println(ad);
    				System.out.println(su);
    				System.out.println(mu);
    				System.out.println(di);
    				System.out.println(mo);
    }
}
}