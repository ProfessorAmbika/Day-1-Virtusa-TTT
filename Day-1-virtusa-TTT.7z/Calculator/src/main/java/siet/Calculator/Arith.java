package siet.Calculator;

public class Arith {

		public int add(int x, int y)
		{
			int z=x+y;
			return z;
		}
		public int sub(int x, int y)
		{
			int z=x-y;
			return z;
		}
		public int multi(int x, int y)
		{
			int z=x*y;
			return z;
		}
		public int div(int x, int y)
		{
			int z=x/y;
			return z;
		}
		public int mod(int x, int y)
		{
			int z=x%y;
			return z;
		}
}
